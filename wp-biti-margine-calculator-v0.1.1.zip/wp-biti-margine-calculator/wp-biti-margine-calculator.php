<?php
/**
 * Plugin Name: WP BiTi - Product Margine Calculator
 * Description: Internal WooCommerce margin/markup calculator with restricted access, history tracking and CSV exports.
 * Version: 0.1.1
 * Author: BiTi - Bogdan Tanasi
 * License: GPL2
 * License URI: https://www.gnu.org
 * Text Domain: wp-biti-margine-calculator
 */

/*  Copyright (C) 2026  BiTi - Bogdan Tanasi (bogdan.tanasi@trattaeribassa.it)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.
*/

/*
        @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@        
     @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@     
   @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@   
 @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ 
 @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@                                               @@@@@@@@@@@@@@
@@@@@@@@                                                   @@@@@@@@@@
@@@@@@@@                                                    @@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@        @@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@        @@@@@@@
@@@@@@@@                    @@@@@@@@@@@@@@@@@@@@@@@@@@@       @@@@@@@
@@@@@@@@                    @@@@@@@@@@@@@@@@@@@@@@@@@@@       @@@@@@@
@@@@@@@@                    @@@@@@@@@@@@@@@@@@@@@@@@@@       @@@@@@@@
@@@@@@@@@@@@@@@@@@@@@       @@@@@@@@@@@@@@@@@@@@@@@@         @@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@      @@@@@                          @@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@      @@@@@                         @@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@      @@@@@                      @@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@      @@@@@       @@         @@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@      @@@@@       @@@@         @@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@      @@@@@       @@@@@@         @@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@      @@@@@       @@@@@@@@         @@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@      @@@@@       @@@@@@@@@@         @@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@      @@@@@       @@@@@@@@@@@         @@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@      @@@@@       @@@@@@@@@@@@@         @@@@@@@
@@@@@@@@@@@@@@@@@@@@@@      @@@@@       @@@@@@@@@@@@@@@         @@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
 @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
 @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ 
   @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@   
     @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@     
        @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@        
*/

if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'TRCM_VERSION', '0.1.1' );
define( 'TRCM_SLUG', 'wp-biti-margine-calculator' );
define( 'TRCM_OPTION_KEY', 'trcm_settings' );

final class WP_BiTi_Product_Margine_Calculator {

	/** Ruoli abilitati */
	private static array $allowed_roles = [
		'administrator',
		'shop_manager',
		'subscriber',
		'author',
		'contributor',
		'editor',
	];

	/** Query var per endpoint frontend */
	private const QV_ENDPOINT = 'trcm';

	/** Slug endpoint */
	private const DEFAULT_ENDPOINT_SLUG = 'calcolo-margine';

	/** Nome tabella storico */
	private static function table_name(): string {
		global $wpdb;
		return $wpdb->prefix . 'trcm_history';
	}

	public static function init(): void {
		// Rewrite endpoint frontend (virtual page)
		add_action( 'init', [ __CLASS__, 'register_rewrite' ] );
		add_filter( 'query_vars', [ __CLASS__, 'register_query_vars' ] );
		add_action( 'template_redirect', [ __CLASS__, 'maybe_render_frontend_endpoint' ] );

		
		// Se una pagina contiene lo shortcode, forza 403 per utenti non autorizzati
		add_action( 'template_redirect', [ __CLASS__, 'maybe_block_shortcode_pages' ] );
// Shortcode (per pagina WordPress: es. /calcolo-margine-privato/)
		add_shortcode( 'tratta_margine_calculator', [ __CLASS__, 'shortcode' ] );

		// Noindex su pagine che contengono lo shortcode
		add_filter( 'wp_robots', [ __CLASS__, 'maybe_noindex_shortcode_pages' ] );

		// Admin page
		add_action( 'admin_menu', [ __CLASS__, 'register_admin_menu' ] );

		
		add_action( 'admin_init', [ __CLASS__, 'handle_settings_save' ] );
// Assets
		add_action( 'admin_enqueue_scripts', [ __CLASS__, 'enqueue_admin_assets' ] );
		add_action( 'wp_enqueue_scripts', [ __CLASS__, 'enqueue_frontend_assets' ] );

		// AJAX
		add_action( 'wp_ajax_trcm_get_product', [ __CLASS__, 'ajax_get_product' ] );
		add_action( 'wp_ajax_trcm_save_calc', [ __CLASS__, 'ajax_save_calc' ] );

		// Export CSV (admin-post funziona anche da frontend per utenti loggati)
		add_action( 'admin_post_trcm_export_history', [ __CLASS__, 'export_history_csv' ] );
		add_action( 'admin_post_trcm_export_last_calc', [ __CLASS__, 'export_last_calc_csv' ] );

		// Default settings
		add_action( 'init', [ __CLASS__, 'ensure_default_settings' ] );

		// Admin notices (WooCommerce)
		add_action( 'admin_notices', [ __CLASS__, 'admin_notice_missing_wc' ] );
	}

	public static function activate(): void {
		self::ensure_default_settings();
		self::create_table();
		self::register_rewrite();
		flush_rewrite_rules();
	}

	public static function deactivate(): void {
		flush_rewrite_rules();
	}

	public static function admin_notice_missing_wc(): void {
		if ( ! is_admin() ) { return; }
		if ( current_user_can( 'activate_plugins' ) && ! class_exists( 'WooCommerce' ) ) {
			echo '<div class="notice notice-warning"><p><strong>Tratta e Ribassa — Calcolo Margine</strong>: WooCommerce non risulta attivo. La ricerca prodotto (SKU/ID) potrebbe non funzionare.</p></div>';
		}
	}

	private static function settings(): array {
		$defaults = [
			'endpoint_slug' => self::DEFAULT_ENDPOINT_SLUG,
			'default_sconto' => 57.50,
			'default_iva' => 22.00,
			'default_ricarico' => 20.00,
			'default_margine' => 20.00,
			'history_limit' => 20,
		];
		$opt = get_option( TRCM_OPTION_KEY, [] );
		if ( ! is_array( $opt ) ) { $opt = []; }
		return array_merge( $defaults, $opt );
	}

	public static function ensure_default_settings(): void {
		$opt = get_option( TRCM_OPTION_KEY, null );
		if ( null === $opt ) {
			add_option( TRCM_OPTION_KEY, self::settings(), '', false );
		}
	}


	public static function handle_settings_save(): void {
		if ( ! is_admin() ) { return; }
		if ( ! isset( $_POST['trcm_save_settings'] ) ) { return; }

		// Access control: only allowed roles
		if ( ! self::user_allowed() ) {
			wp_die( esc_html__( 'Accesso negato (403).', 'wp-biti-margine-calculator' ), esc_html__( 'Accesso negato', 'wp-biti-margine-calculator' ), [ 'response' => 403 ] );
		}

		// Nonce check
		if ( ! isset( $_POST['trcm_settings_nonce'] ) || ! wp_verify_nonce( (string) $_POST['trcm_settings_nonce'], 'trcm_save_settings' ) ) {
			wp_die( esc_html__( 'Richiesta non valida (nonce).', 'wp-biti-margine-calculator' ) );
		}

		$old = self::settings();

		$endpoint_slug = isset( $_POST['endpoint_slug'] ) ? sanitize_title( (string) wp_unslash( $_POST['endpoint_slug'] ) ) : self::DEFAULT_ENDPOINT_SLUG;
		if ( ! $endpoint_slug ) { $endpoint_slug = self::DEFAULT_ENDPOINT_SLUG; }

		$default_sconto  = isset( $_POST['default_sconto'] )  ? self::parse_num( wp_unslash( $_POST['default_sconto'] ) )  : (float) $old['default_sconto'];
		$default_iva     = isset( $_POST['default_iva'] )     ? self::parse_num( wp_unslash( $_POST['default_iva'] ) )     : (float) $old['default_iva'];
		$default_ricarico= isset( $_POST['default_ricarico'] )? self::parse_num( wp_unslash( $_POST['default_ricarico'] ) ): (float) $old['default_ricarico'];
		$default_margine = isset( $_POST['default_margine'] ) ? self::parse_num( wp_unslash( $_POST['default_margine'] ) ) : (float) $old['default_margine'];

		$history_limit = isset( $_POST['history_limit'] ) ? absint( $_POST['history_limit'] ) : (int) $old['history_limit'];
		if ( $history_limit < 1 ) { $history_limit = 1; }
		if ( $history_limit > 200 ) { $history_limit = 200; }

		$new = [
			'endpoint_slug'   => $endpoint_slug,
			'default_sconto'  => $default_sconto,
			'default_iva'     => $default_iva,
			'default_ricarico'=> $default_ricarico,
			'default_margine' => $default_margine,
			'history_limit'   => $history_limit,
		];

		update_option( TRCM_OPTION_KEY, $new, false );

		// If endpoint slug changed, refresh rewrite rules
		if ( (string) $old['endpoint_slug'] !== (string) $endpoint_slug ) {
			self::register_rewrite();
			flush_rewrite_rules();
		}

		set_transient( 'trcm_admin_notice', 'Impostazioni salvate.', 30 );
	}



	private static function user_allowed(): bool {
		if ( ! is_user_logged_in() ) { return false; }
		$user = wp_get_current_user();
		if ( empty( $user->roles ) ) { return false; }
		foreach ( $user->roles as $r ) {
			if ( in_array( $r, self::$allowed_roles, true ) ) { return true; }
		}
		return false;
	}

	private static function send_noindex_headers(): void {
		// Header per bots + meta robots
		if ( ! headers_sent() ) {
			header( 'X-Robots-Tag: noindex, nofollow, noarchive', true );
		}
		// Per WP 5.7+ (wp_robots)
		add_filter( 'wp_robots', function( $robots ) {
			$robots['noindex']  = true;
			$robots['nofollow'] = true;
			$robots['noarchive'] = true;
			return $robots;
		} );
	}

	public static function maybe_noindex_shortcode_pages( array $robots ): array {
		if ( is_singular() ) {
			$post = get_post();
			if ( $post && has_shortcode( (string) $post->post_content, 'tratta_margine_calculator' ) ) {
				$robots['noindex']   = true;
				$robots['nofollow']  = true;
				$robots['noarchive'] = true;
			}
		}
		return $robots;
	}

	public static function register_rewrite(): void {
		$settings = self::settings();
		$slug = sanitize_title( (string) ( $settings['endpoint_slug'] ?? self::DEFAULT_ENDPOINT_SLUG ) );
		if ( ! $slug ) { $slug = self::DEFAULT_ENDPOINT_SLUG; }
		add_rewrite_rule( '^' . preg_quote( $slug, '/' ) . '/?$', 'index.php?' . self::QV_ENDPOINT . '=1', 'top' );
	}

	public static function register_query_vars( array $vars ): array {
		$vars[] = self::QV_ENDPOINT;
		return $vars;
	}

	public static function maybe_render_frontend_endpoint(): void {
		if ( (int) get_query_var( self::QV_ENDPOINT ) !== 1 ) { return; }

		self::send_noindex_headers();

		if ( ! self::user_allowed() ) {
			status_header( 403 );
			nocache_headers();
			wp_die( esc_html__( 'Accesso negato (403).', 'wp-biti-margine-calculator' ), esc_html__( 'Accesso negato', 'wp-biti-margine-calculator' ), [ 'response' => 403 ] );
		}

		status_header( 200 );
		nocache_headers();

		// Rendering minimale con head/footer di WP per includere asset correttamente
		add_filter( 'show_admin_bar', '__return_false' );

		get_header();
		echo '<div class="trcm-endpoint">';
		echo self::render_calculator_ui( 'frontend-endpoint' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo '</div>';
		get_footer();
		exit;
	}

	
	public static function maybe_block_shortcode_pages(): void {
		if ( ! is_singular() ) { return; }
		$post = get_post();
		if ( ! $post ) { return; }
		if ( ! has_shortcode( (string) $post->post_content, 'tratta_margine_calculator' ) ) { return; }

		self::send_noindex_headers();

		if ( self::user_allowed() ) { return; }

		status_header( 403 );
		nocache_headers();
		wp_die( esc_html__( 'Accesso negato (403).', 'wp-biti-margine-calculator' ), esc_html__( 'Accesso negato', 'wp-biti-margine-calculator' ), [ 'response' => 403 ] );
	}

	public static function shortcode( $atts = [] ): string {
		self::send_noindex_headers();

		if ( ! self::user_allowed() ) {
			return '<div class="trcm-denied"><strong>Accesso negato (403).</strong></div>';
		}
		return self::render_calculator_ui( 'shortcode' );
	}

	public static function register_admin_menu(): void {
		// Mettiamo sotto WooCommerce. Capability: read (poi validiamo ruoli internamente)
		add_submenu_page(
			'woocommerce',
			'Calcolo Margine',
			'Calcolo Margine',
			'read',
			'trcm-calcolo-margine',
			[ __CLASS__, 'render_admin_page' ]
		);
	}

	public static function render_admin_page(): void {
		if ( ! self::user_allowed() ) {
			wp_die( esc_html__( 'Accesso negato (403).', 'wp-biti-margine-calculator' ), esc_html__( 'Accesso negato', 'wp-biti-margine-calculator' ), [ 'response' => 403 ] );
		}

		echo '<div class="wrap">';
		echo '<h1>Calcolo Margine</h1>';
		$notice = get_transient( 'trcm_admin_notice' );
		if ( $notice ) {
			delete_transient( 'trcm_admin_notice' );
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( (string) $notice ) . '</p></div>';
		}


		$settings = self::settings();
		echo '<div class="trcm-card" style="max-width:1100px;margin:14px 0;">';
		echo '<h2>Impostazioni rapide</h2>';
		echo '<form method="post">';
		wp_nonce_field( 'trcm_save_settings', 'trcm_settings_nonce' );
		echo '<input type="hidden" name="trcm_save_settings" value="1" />';
		echo '<div class="trcm-row">';
		echo '<div class="trcm-field"><label>Slug endpoint (frontend)</label><input name="endpoint_slug" value="' . esc_attr( (string) $settings['endpoint_slug'] ) . '" /></div>';
		echo '<div class="trcm-field"><label>Storico: righe</label><input name="history_limit" value="' . esc_attr( (string) $settings['history_limit'] ) . '" /></div>';
		echo '</div>';
		echo '<div class="trcm-row">';
		echo '<div class="trcm-field"><label>Default sconto (%)</label><input name="default_sconto" value="' . esc_attr( number_format( (float) $settings['default_sconto'], 2, ',', '' ) ) . '" /></div>';
		echo '<div class="trcm-field"><label>Default IVA (%)</label><input name="default_iva" value="' . esc_attr( number_format( (float) $settings['default_iva'], 2, ',', '' ) ) . '" /></div>';
		echo '<div class="trcm-field"><label>Default ricarico (%)</label><input name="default_ricarico" value="' . esc_attr( number_format( (float) $settings['default_ricarico'], 2, ',', '' ) ) . '" /></div>';
		echo '<div class="trcm-field"><label>Default margine (%)</label><input name="default_margine" value="' . esc_attr( number_format( (float) $settings['default_margine'], 2, ',', '' ) ) . '" /></div>';
		echo '</div>';
		echo '<p><button type="submit" class="button button-primary">Salva impostazioni</button></p>';
		echo '</form>';
		echo '</div>';

		echo self::render_calculator_ui( 'admin' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo '</div>';
	}

	private static function should_enqueue_on_front(): bool {
		// Endpoint virtuale
		if ( (int) get_query_var( self::QV_ENDPOINT ) === 1 ) { return true; }

		// Pagine con shortcode
		if ( is_singular() ) {
			$post = get_post();
			if ( $post && has_shortcode( (string) $post->post_content, 'tratta_margine_calculator' ) ) {
				return true;
			}
		}
		return false;
	}

	public static function enqueue_frontend_assets(): void {
		if ( ! self::should_enqueue_on_front() ) { return; }
		self::enqueue_common_assets( 'frontend' );
	}

	public static function enqueue_admin_assets( $hook ): void {
		// Carichiamo solo sulla nostra pagina admin
		if ( 'woocommerce_page_trcm-calcolo-margine' !== $hook ) { return; }
		self::enqueue_common_assets( 'admin' );
	}

	private static function enqueue_common_assets( string $context ): void {
		wp_enqueue_style(
			'trcm-style',
			plugins_url( 'assets/style.css', __FILE__ ),
			[],
			TRCM_VERSION
		);

		wp_enqueue_script( 'jquery' );

		wp_enqueue_script(
			'trcm-app',
			plugins_url( 'assets/app.js', __FILE__ ),
			[ 'jquery' ],
			TRCM_VERSION,
			true
		);

		$settings = self::settings();

		wp_localize_script( 'trcm-app', 'TRCM', [
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			'nonce'   => wp_create_nonce( 'trcm_nonce' ),
			'defaults' => [
				'sconto'   => (float) $settings['default_sconto'],
				'iva'      => (float) $settings['default_iva'],
				'ricarico' => (float) $settings['default_ricarico'],
				'margine'  => (float) $settings['default_margine'],
			],
			'historyLimit' => (int) $settings['history_limit'],
			'context' => $context,
		] );
	}

	private static function render_calculator_ui( string $context ): string {
		$settings = self::settings();
		$defaults = [
			'sconto'   => (float) $settings['default_sconto'],
			'iva'      => (float) $settings['default_iva'],
			'ricarico' => (float) $settings['default_ricarico'],
			'margine'  => (float) $settings['default_margine'],
		];

		$history = self::get_history( get_current_user_id(), (int) $settings['history_limit'] );

		// Forms export
		$export_history_action = esc_url( admin_url( 'admin-post.php' ) );
		$nonce_history = wp_create_nonce( 'trcm_export_history' );
		$nonce_last    = wp_create_nonce( 'trcm_export_last_calc' );

		ob_start();
		?>
		<div class="trcm-wrap" data-trcm-context="<?php echo esc_attr( $context ); ?>">
			<div class="trcm-topbar">
				<div class="trcm-note">
					<strong>Pagina interna.</strong> Accesso consentito solo ai ruoli autorizzati. Indicizzazione disabilitata (noindex).
				</div>
			</div>

			<div class="trcm-card">
				<h2>Carica prodotto (opzionale)</h2>
				<div class="trcm-row">
					<div class="trcm-field">
						<label for="trcm_sku">SKU o ID Prodotto</label>
						<input type="text" id="trcm_sku" placeholder="Es: TR-123 oppure 1234" autocomplete="off" />
					</div>
					<div class="trcm-field trcm-field--btn">
						<button type="button" class="button button-primary" id="trcm_load_product">Carica</button>
					</div>
				</div>
				<div id="trcm_product_info" class="trcm-muted"></div>
				<input type="hidden" id="trcm_product_id" value="" />
				<input type="hidden" id="trcm_product_name" value="" />
			</div>

			<div class="trcm-grid">
				<div class="trcm-card">
					<h2>Dati base</h2>

					<div class="trcm-row">
						<div class="trcm-field">
							<label for="trcm_listino_escl">Listino IVA esclusa</label>
							<input type="text" id="trcm_listino_escl" inputmode="decimal" placeholder="0,00" />
						</div>
						<div class="trcm-field">
							<label for="trcm_iva">Aliquota IVA (%)</label>
							<input type="text" id="trcm_iva" inputmode="decimal" value="<?php echo esc_attr( number_format( $defaults['iva'], 2, ',', '' ) ); ?>" />
						</div>
						<div class="trcm-field">
							<label for="trcm_sconto">Sconto % fornitore (%)</label>
							<input type="text" id="trcm_sconto" inputmode="decimal" value="<?php echo esc_attr( number_format( $defaults['sconto'], 2, ',', '' ) ); ?>" />
						</div>
					</div>

					<div class="trcm-row">
						<div class="trcm-kpi">
							<div class="trcm-kpi__label">Listino IVA inclusa</div>
							<div class="trcm-kpi__value"><span id="trcm_out_listino_incl">—</span> <button class="trcm-copy" data-copy="#trcm_out_listino_incl">Copia</button></div>
						</div>
						<div class="trcm-kpi">
							<div class="trcm-kpi__label">Prezzo tuo IVA inclusa</div>
							<div class="trcm-kpi__value"><span id="trcm_out_prezzo_tuo_incl">—</span> <button class="trcm-copy" data-copy="#trcm_out_prezzo_tuo_incl">Copia</button></div>
						</div>
						<div class="trcm-kpi">
							<div class="trcm-kpi__label">Costo reale senza IVA</div>
							<div class="trcm-kpi__value"><span id="trcm_out_costo_reale">—</span> <button class="trcm-copy" data-copy="#trcm_out_costo_reale">Copia</button></div>
						</div>
					</div>
				</div>

				<div class="trcm-card">
					<h2>Parametri + azioni</h2>

					<div class="trcm-row">
						<div class="trcm-field">
							<label for="trcm_ricarico">RICARICO (%)</label>
							<input type="text" id="trcm_ricarico" inputmode="decimal" value="<?php echo esc_attr( number_format( $defaults['ricarico'], 2, ',', '' ) ); ?>" />
						</div>
						<div class="trcm-field">
							<label for="trcm_margine_des">MARGINE desiderato (%)</label>
							<input type="text" id="trcm_margine_des" inputmode="decimal" value="<?php echo esc_attr( number_format( $defaults['margine'], 2, ',', '' ) ); ?>" />
						</div>
					</div>

					<div class="trcm-actions">
						<button type="button" class="button button-secondary" id="trcm_save_calc">Salva nello storico</button>

						<form method="post" action="<?php echo $export_history_action; ?>" class="trcm-export-form">
							<input type="hidden" name="action" value="trcm_export_history" />
							<input type="hidden" name="_wpnonce" value="<?php echo esc_attr( $nonce_history ); ?>" />
							<button type="submit" class="button">Esporta CSV storico</button>
						</form>

						<form method="post" action="<?php echo $export_history_action; ?>" class="trcm-export-form" id="trcm_export_last_form">
							<input type="hidden" name="action" value="trcm_export_last_calc" />
							<input type="hidden" name="_wpnonce" value="<?php echo esc_attr( $nonce_last ); ?>" />
							<input type="hidden" name="payload" id="trcm_export_last_payload" value="" />
							<button type="submit" class="button button-primary" id="trcm_export_last_btn">Esporta CSV ultimo calcolo</button>
						</form>

						<div class="trcm-muted" id="trcm_save_status"></div>
					</div>
				</div>
			</div>

			<div class="trcm-grid trcm-grid--2">
				<div class="trcm-card">
					<h2>Calcolo da RICARICO</h2>

					<div class="trcm-row trcm-row--kpi2">
						<div class="trcm-kpi">
							<div class="trcm-kpi__label">Prezzo vendita senza IVA</div>
							<div class="trcm-kpi__value"><span id="trcm_out_vendita_escl_ric">—</span> <button class="trcm-copy" data-copy="#trcm_out_vendita_escl_ric">Copia</button></div>
						</div>
						<div class="trcm-kpi">
							<div class="trcm-kpi__label">Prezzo vendita IVA inclusa</div>
							<div class="trcm-kpi__value"><span id="trcm_out_vendita_incl_ric">—</span> <button class="trcm-copy" data-copy="#trcm_out_vendita_incl_ric">Copia</button></div>
						</div>
					</div>

					<div class="trcm-row trcm-row--kpi2">
						<div class="trcm-kpi">
							<div class="trcm-kpi__label">Margine reale risultante</div>
							<div class="trcm-kpi__value"><span id="trcm_out_margine_reale_ric">—</span></div>
						</div>
						<div class="trcm-kpi">
							<div class="trcm-kpi__label">Margine € IVA esclusa</div>
							<div class="trcm-kpi__value"><span id="trcm_out_margine_euro_escl_ric">—</span> <button class="trcm-copy" data-copy="#trcm_out_margine_euro_escl_ric">Copia</button></div>
						</div>
					</div>

					<div class="trcm-row">
						<div class="trcm-kpi">
							<div class="trcm-kpi__label">Margine € IVA inclusa</div>
							<div class="trcm-kpi__value"><span id="trcm_out_margine_euro_incl_ric">—</span> <button class="trcm-copy" data-copy="#trcm_out_margine_euro_incl_ric">Copia</button></div>
						</div>
					</div>
				</div>

				<div class="trcm-card">
					<h2>Calcolo da MARGINE desiderato</h2>

					<div class="trcm-row trcm-row--kpi2">
						<div class="trcm-kpi">
							<div class="trcm-kpi__label">Prezzo vendita senza IVA</div>
							<div class="trcm-kpi__value"><span id="trcm_out_vendita_escl_mar">—</span> <button class="trcm-copy" data-copy="#trcm_out_vendita_escl_mar">Copia</button></div>
						</div>
						<div class="trcm-kpi">
							<div class="trcm-kpi__label">Prezzo vendita IVA inclusa</div>
							<div class="trcm-kpi__value"><span id="trcm_out_vendita_incl_mar">—</span> <button class="trcm-copy" data-copy="#trcm_out_vendita_incl_mar">Copia</button></div>
						</div>
					</div>

					<div class="trcm-row trcm-row--kpi2">
						<div class="trcm-kpi">
							<div class="trcm-kpi__label">Ricarico risultante</div>
							<div class="trcm-kpi__value"><span id="trcm_out_ricarico_ris">—</span></div>
						</div>
						<div class="trcm-kpi">
							<div class="trcm-kpi__label">Margine € IVA esclusa</div>
							<div class="trcm-kpi__value"><span id="trcm_out_margine_euro_escl_mar">—</span> <button class="trcm-copy" data-copy="#trcm_out_margine_euro_escl_mar">Copia</button></div>
						</div>
					</div>

					<div class="trcm-row">
						<div class="trcm-kpi">
							<div class="trcm-kpi__label">Margine € IVA inclusa</div>
							<div class="trcm-kpi__value"><span id="trcm_out_margine_euro_incl_mar">—</span> <button class="trcm-copy" data-copy="#trcm_out_margine_euro_incl_mar">Copia</button></div>
						</div>
					</div>
				</div>
			</div>

			<div class="trcm-card">
				<h2>Storico (ultimi <?php echo (int) $settings['history_limit']; ?>)</h2>
				<div class="trcm-muted">Per esportare: usa “Esporta CSV storico”.</div>
				<div class="trcm-table-wrap">
					<table class="widefat striped trcm-table" id="trcm_history_table">
						<thead>
							<tr>
								<th>Data</th>
								<th>Prodotto</th>
								<th>Listino IVA escl.</th>
								<th>IVA</th>
								<th>Sconto</th>
								<th>Ricarico</th>
								<th>Margine</th>
								<th>Vendita IVA incl. (da ricarico)</th>
								<th>Vendita IVA incl. (da margine)</th>
							</tr>
						</thead>
						<tbody>
							<?php echo self::render_history_rows( $history ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						</tbody>
					</table>
				</div>
			</div>

			<div class="trcm-footnote trcm-muted">
				Endpoint rapido: <code><?php echo esc_html( home_url( '/' . sanitize_title( (string) $settings['endpoint_slug'] ) . '/' ) ); ?></code>
				<br/>Shortcode: <code>[tratta_margine_calculator]</code>
			</div>
		</div>
		<?php
		return (string) ob_get_clean();
	}

	private static function render_history_rows( array $history ): string {
		if ( empty( $history ) ) {
			return '<tr><td colspan="9" class="trcm-muted">Nessun calcolo salvato.</td></tr>';
		}
		$out = '';
		foreach ( $history as $row ) {
			$date = esc_html( mysql2date( 'd/m/Y H:i', (string) $row['created_at'] ) );
			$prod = esc_html( (string) ( $row['product_name'] ?: $row['sku'] ?: '—' ) );
			$listino = esc_html( self::fmt_money( (float) $row['listino_escl'] ) );
			$iva = esc_html( self::fmt_percent( (float) $row['iva_rate'] * 100 ) );
			$sconto = esc_html( self::fmt_percent( (float) $row['sconto_rate'] * 100 ) );
			$ricarico = esc_html( self::fmt_percent( (float) $row['ricarico_rate'] * 100 ) );
			$margine = esc_html( self::fmt_percent( (float) $row['margine_des_rate'] * 100 ) );
			$vendita_ric_incl = esc_html( self::fmt_money( (float) $row['vendita_incl_ric'] ) );
			$vendita_mar_incl = esc_html( self::fmt_money( (float) $row['vendita_incl_mar'] ) );

			$out .= '<tr>';
			$out .= '<td>' . $date . '</td>';
			$out .= '<td>' . $prod . '</td>';
			$out .= '<td>' . $listino . '</td>';
			$out .= '<td>' . $iva . '</td>';
			$out .= '<td>' . $sconto . '</td>';
			$out .= '<td>' . $ricarico . '</td>';
			$out .= '<td>' . $margine . '</td>';
			$out .= '<td>' . $vendita_ric_incl . '</td>';
			$out .= '<td>' . $vendita_mar_incl . '</td>';
			$out .= '</tr>';
		}
		return $out;
	}

	/* =========================
	 *  CALCOLI (come Excel)
	 * ========================= */

	private static function parse_num( $raw ): float {
		$s = is_scalar( $raw ) ? (string) $raw : '';
		$s = trim( $s );
		$s = str_replace( [ ' ', '€' ], '', $s );
		$s = str_replace( '.', '', $s ); // migliaia IT
		$s = str_replace( ',', '.', $s ); // decimali IT
		if ( $s === '' ) { return 0.0; }
		return (float) $s;
	}

	private static function clamp_rate( float $rate ): float {
		if ( $rate < 0 ) { $rate = 0; }
		if ( $rate > 0.999999 ) { $rate = 0.999999; }
		return $rate;
	}

	/**
	 * @param array{listino_escl:float, iva:float, sconto:float, ricarico:float, margine:float} $in
	 * Percentuali in input come "22" = 22%
	 */
	private static function compute( array $in ): array {
		$listino_escl = max( 0.0, (float) $in['listino_escl'] );
		$iva_rate     = self::clamp_rate( (float) $in['iva'] / 100.0 );
		$sconto_rate  = self::clamp_rate( (float) $in['sconto'] / 100.0 );
		$ric_rate     = max( 0.0, (float) $in['ricarico'] / 100.0 );
		$mar_rate     = self::clamp_rate( (float) $in['margine'] / 100.0 );

		// Excel:
		// listino_incl = listino_escl * (1 + iva)
		$listino_incl = $listino_escl * ( 1 + $iva_rate );

		// prezzo_tuo_incl = listino_incl * (1 - sconto)
		$prezzo_tuo_incl = $listino_incl * ( 1 - $sconto_rate );

		// costo_reale_escl = prezzo_tuo_incl / (1 + iva)
		$costo_reale = ( ( 1 + $iva_rate ) > 0 ) ? ( $prezzo_tuo_incl / ( 1 + $iva_rate ) ) : 0.0;

		// Modalità RICARICO
		$vendita_escl_ric = $costo_reale * ( 1 + $ric_rate );
		$vendita_incl_ric = $vendita_escl_ric * ( 1 + $iva_rate );
		$margine_reale_ric = ( $vendita_escl_ric > 0 ) ? ( ( $vendita_escl_ric - $costo_reale ) / $vendita_escl_ric ) : 0.0;
		$margine_euro_escl_ric = $vendita_escl_ric - $costo_reale;
		$margine_euro_incl_ric = $vendita_incl_ric - $prezzo_tuo_incl;

		// Modalità MARGINE DESIDERATO
		$vendita_escl_mar = ( ( 1 - $mar_rate ) > 0 ) ? ( $costo_reale / ( 1 - $mar_rate ) ) : 0.0;
		$vendita_incl_mar = $vendita_escl_mar * ( 1 + $iva_rate );
		$ricarico_ris = ( $costo_reale > 0 ) ? ( ( $vendita_escl_mar - $costo_reale ) / $costo_reale ) : 0.0;
		$margine_euro_escl_mar = $vendita_escl_mar - $costo_reale;
		$margine_euro_incl_mar = $vendita_incl_mar - $prezzo_tuo_incl;

		return [
			'listino_escl' => $listino_escl,
			'iva_rate' => $iva_rate,
			'sconto_rate' => $sconto_rate,
			'ricarico_rate' => $ric_rate,
			'margine_des_rate' => $mar_rate,

			'listino_incl' => $listino_incl,
			'prezzo_tuo_incl' => $prezzo_tuo_incl,
			'costo_reale' => $costo_reale,

			'vendita_escl_ric' => $vendita_escl_ric,
			'vendita_incl_ric' => $vendita_incl_ric,
			'margine_reale_ric' => $margine_reale_ric,
			'margine_euro_escl_ric' => $margine_euro_escl_ric,
			'margine_euro_incl_ric' => $margine_euro_incl_ric,

			'vendita_escl_mar' => $vendita_escl_mar,
			'vendita_incl_mar' => $vendita_incl_mar,
			'ricarico_ris' => $ricarico_ris,
			'margine_euro_escl_mar' => $margine_euro_escl_mar,
			'margine_euro_incl_mar' => $margine_euro_incl_mar,
		];
	}

	private static function fmt_money( float $v ): string {
		return number_format( (float) $v, 2, ',', '.' );
	}

	private static function fmt_percent( float $v ): string {
		return number_format( (float) $v, 2, ',', '' ) . '%';
	}

	/* =========================
	 *  AJAX
	 * ========================= */

	private static function ajax_guard(): void {
		if ( ! self::user_allowed() ) {
			wp_send_json_error( [ 'message' => 'Accesso negato.' ], 403 );
		}
		check_ajax_referer( 'trcm_nonce', 'nonce' );
	}

	public static function ajax_get_product(): void {
		self::ajax_guard();

		if ( ! class_exists( 'WooCommerce' ) ) {
			wp_send_json_error( [ 'message' => 'WooCommerce non attivo.' ], 400 );
		}

		$raw = isset( $_POST['query'] ) ? sanitize_text_field( wp_unslash( $_POST['query'] ) ) : '';
		$raw = trim( $raw );
		if ( $raw === '' ) {
			wp_send_json_error( [ 'message' => 'Inserisci SKU o ID.' ], 400 );
		}

		$product_id = 0;
		if ( ctype_digit( $raw ) ) {
			$product_id = (int) $raw;
		} else {
			$product_id = (int) wc_get_product_id_by_sku( $raw );
		}

		if ( $product_id <= 0 ) {
			wp_send_json_error( [ 'message' => 'Prodotto non trovato.' ], 404 );
		}

		$product = wc_get_product( $product_id );
		if ( ! $product ) {
			wp_send_json_error( [ 'message' => 'Prodotto non valido.' ], 404 );
		}

		$sku = (string) $product->get_sku();
		$name = (string) $product->get_name();

		// Prezzo base (regular) come inserito in WooCommerce
		$regular = (float) $product->get_regular_price();
		$sale    = (float) $product->get_sale_price();

		$price_raw = $regular > 0 ? $regular : ( $sale > 0 ? $sale : (float) $product->get_price() );

		// Tax class e aliquota stimata
		$tax_class = $product->get_tax_class();
		$tax_rates = class_exists( 'WC_Tax' ) ? WC_Tax::get_rates( $tax_class ) : [];
		$tax_rate_pct = 0.0;
		if ( ! empty( $tax_rates ) ) {
			$first = array_shift( $tax_rates );
			if ( isset( $first['rate'] ) ) {
				$tax_rate_pct = (float) $first['rate'];
			}
		}

		// Se non troviamo un'aliquota, fallback a default plugin (22)
		if ( $tax_rate_pct <= 0 ) {
			$tax_rate_pct = (float) ( self::settings()['default_iva'] ?? 22.0 );
		}

		$prices_include_tax = ( 'yes' === get_option( 'woocommerce_prices_include_tax', 'no' ) );
		$listino_escl = $price_raw;
		if ( $prices_include_tax ) {
			$listino_escl = ( ( 1 + ( $tax_rate_pct / 100.0 ) ) > 0 ) ? ( $price_raw / ( 1 + ( $tax_rate_pct / 100.0 ) ) ) : $price_raw;
		}

		wp_send_json_success( [
			'product_id' => $product_id,
			'sku' => $sku,
			'name' => $name,
			'price_raw' => $price_raw,
			'prices_include_tax' => $prices_include_tax,
			'iva_pct' => $tax_rate_pct,
			'listino_escl' => $listino_escl,
		] );
	}

	public static function ajax_save_calc(): void {
		self::ajax_guard();

		$payload = isset( $_POST['payload'] ) ? (array) json_decode( (string) wp_unslash( $_POST['payload'] ), true ) : [];
		if ( empty( $payload ) || ! is_array( $payload ) ) {
			wp_send_json_error( [ 'message' => 'Payload non valido.' ], 400 );
		}

		$in = [
			'listino_escl' => self::parse_num( $payload['listino_escl'] ?? 0 ),
			'iva'          => self::parse_num( $payload['iva'] ?? 0 ),
			'sconto'       => self::parse_num( $payload['sconto'] ?? 0 ),
			'ricarico'     => self::parse_num( $payload['ricarico'] ?? 0 ),
			'margine'      => self::parse_num( $payload['margine'] ?? 0 ),
		];
		$out = self::compute( $in );

		$meta = [
			'product_id' => isset( $payload['product_id'] ) ? (int) $payload['product_id'] : 0,
			'sku' => isset( $payload['sku'] ) ? sanitize_text_field( (string) $payload['sku'] ) : '',
			'product_name' => isset( $payload['product_name'] ) ? sanitize_text_field( (string) $payload['product_name'] ) : '',
		];

		$ok = self::insert_history( get_current_user_id(), $meta, $out );

		if ( ! $ok ) {
			wp_send_json_error( [ 'message' => 'Impossibile salvare nello storico.' ], 500 );
		}

		$settings = self::settings();
		$history = self::get_history( get_current_user_id(), (int) $settings['history_limit'] );

		wp_send_json_success( [
			'message' => 'Salvato.',
			'history_html' => self::render_history_rows( $history ),
		] );
	}

	/* =========================
	 *  STORICO (DB)
	 * ========================= */

	private static function create_table(): void {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$table = self::table_name();
		$charset = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE {$table} (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			user_id BIGINT(20) UNSIGNED NOT NULL,
			created_at DATETIME NOT NULL,
			product_id BIGINT(20) UNSIGNED NULL,
			sku VARCHAR(64) NULL,
			product_name VARCHAR(255) NULL,

			listino_escl DECIMAL(20,6) NOT NULL DEFAULT 0,
			iva_rate DECIMAL(10,6) NOT NULL DEFAULT 0,
			sconto_rate DECIMAL(10,6) NOT NULL DEFAULT 0,
			ricarico_rate DECIMAL(10,6) NOT NULL DEFAULT 0,
			margine_des_rate DECIMAL(10,6) NOT NULL DEFAULT 0,

			listino_incl DECIMAL(20,6) NOT NULL DEFAULT 0,
			prezzo_tuo_incl DECIMAL(20,6) NOT NULL DEFAULT 0,
			costo_reale DECIMAL(20,6) NOT NULL DEFAULT 0,

			vendita_escl_ric DECIMAL(20,6) NOT NULL DEFAULT 0,
			vendita_incl_ric DECIMAL(20,6) NOT NULL DEFAULT 0,
			margine_reale_ric DECIMAL(10,6) NOT NULL DEFAULT 0,
			margine_euro_escl_ric DECIMAL(20,6) NOT NULL DEFAULT 0,
			margine_euro_incl_ric DECIMAL(20,6) NOT NULL DEFAULT 0,

			vendita_escl_mar DECIMAL(20,6) NOT NULL DEFAULT 0,
			vendita_incl_mar DECIMAL(20,6) NOT NULL DEFAULT 0,
			ricarico_ris DECIMAL(10,6) NOT NULL DEFAULT 0,
			margine_euro_escl_mar DECIMAL(20,6) NOT NULL DEFAULT 0,
			margine_euro_incl_mar DECIMAL(20,6) NOT NULL DEFAULT 0,

			PRIMARY KEY  (id),
			KEY user_id (user_id),
			KEY created_at (created_at)
		) {$charset};";

		dbDelta( $sql );
	}

	private static function insert_history( int $user_id, array $meta, array $out ): bool {
		global $wpdb;

		$table = self::table_name();

		$data = [
			'user_id' => $user_id,
			'created_at' => current_time( 'mysql' ),
			'product_id' => (int) ( $meta['product_id'] ?? 0 ) ?: null,
			'sku' => (string) ( $meta['sku'] ?? '' ),
			'product_name' => (string) ( $meta['product_name'] ?? '' ),

			'listino_escl' => (string) $out['listino_escl'],
			'iva_rate' => (string) $out['iva_rate'],
			'sconto_rate' => (string) $out['sconto_rate'],
			'ricarico_rate' => (string) $out['ricarico_rate'],
			'margine_des_rate' => (string) $out['margine_des_rate'],

			'listino_incl' => (string) $out['listino_incl'],
			'prezzo_tuo_incl' => (string) $out['prezzo_tuo_incl'],
			'costo_reale' => (string) $out['costo_reale'],

			'vendita_escl_ric' => (string) $out['vendita_escl_ric'],
			'vendita_incl_ric' => (string) $out['vendita_incl_ric'],
			'margine_reale_ric' => (string) $out['margine_reale_ric'],
			'margine_euro_escl_ric' => (string) $out['margine_euro_escl_ric'],
			'margine_euro_incl_ric' => (string) $out['margine_euro_incl_ric'],

			'vendita_escl_mar' => (string) $out['vendita_escl_mar'],
			'vendita_incl_mar' => (string) $out['vendita_incl_mar'],
			'ricarico_ris' => (string) $out['ricarico_ris'],
			'margine_euro_escl_mar' => (string) $out['margine_euro_escl_mar'],
			'margine_euro_incl_mar' => (string) $out['margine_euro_incl_mar'],
		];

		$formats = [
			'%d','%s','%d','%s','%s',
			'%s','%s','%s','%s','%s',
			'%s','%s','%s',
			'%s','%s','%s','%s','%s',
			'%s','%s','%s','%s','%s',
		];

		$inserted = $wpdb->insert( $table, $data, $formats );

		return ( $inserted !== false );
	}

	private static function get_history( int $user_id, int $limit ): array {
		global $wpdb;

		$table = self::table_name();
		$limit = max( 1, min( 200, $limit ) );

		$sql = $wpdb->prepare(
			"SELECT * FROM {$table} WHERE user_id = %d ORDER BY created_at DESC, id DESC LIMIT %d",
			$user_id,
			$limit
		);

		$rows = $wpdb->get_results( $sql, ARRAY_A );
		return is_array( $rows ) ? $rows : [];
	}

	/* =========================
	 *  EXPORT CSV
	 * ========================= */

	private static function export_guard( string $nonce_action ): void {
		if ( ! self::user_allowed() ) {
			wp_die( 'Accesso negato (403).', 'Accesso negato', [ 'response' => 403 ] );
		}
		if ( ! isset( $_POST['_wpnonce'] ) || ! wp_verify_nonce( (string) wp_unslash( $_POST['_wpnonce'] ), $nonce_action ) ) {
			wp_die( 'Nonce non valido.', 'Errore', [ 'response' => 400 ] );
		}
	}

	private static function csv_send_headers( string $filename ): void {
		nocache_headers();
		header( 'Content-Type: text/csv; charset=UTF-8' );
		header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
		echo "\xEF\xBB\xBF"; // UTF-8 BOM per Excel
	}

	public static function export_history_csv(): void {
		self::send_noindex_headers();
		self::export_guard( 'trcm_export_history' );

		$history = self::get_history( get_current_user_id(), 200 );

		self::csv_send_headers( 'storico-calcoli-margine.csv' );

		$fh = fopen( 'php://output', 'w' );
		fputcsv( $fh, [
			'data',
			'product_id',
			'sku',
			'prodotto',
			'listino_iva_escl',
			'iva_%',
			'sconto_%',
			'ricarico_%',
			'margine_desiderato_%',
			'vendita_iva_incl_da_ricarico',
			'vendita_iva_incl_da_margine',
			'margine_reale_da_ricarico_%',
			'ricarico_risultante_da_margine_%',
		] );

		foreach ( $history as $r ) {
			fputcsv( $fh, [
				$r['created_at'],
				$r['product_id'],
				$r['sku'],
				$r['product_name'],
				(string) $r['listino_escl'],
				(string) ( (float) $r['iva_rate'] * 100 ),
				(string) ( (float) $r['sconto_rate'] * 100 ),
				(string) ( (float) $r['ricarico_rate'] * 100 ),
				(string) ( (float) $r['margine_des_rate'] * 100 ),
				(string) $r['vendita_incl_ric'],
				(string) $r['vendita_incl_mar'],
				(string) ( (float) $r['margine_reale_ric'] * 100 ),
				(string) ( (float) $r['ricarico_ris'] * 100 ),
			] );
		}
		fclose( $fh );
		exit;
	}

	public static function export_last_calc_csv(): void {
		self::send_noindex_headers();
		self::export_guard( 'trcm_export_last_calc' );

		$payload_raw = isset( $_POST['payload'] ) ? (string) wp_unslash( $_POST['payload'] ) : '';
		$payload = json_decode( $payload_raw, true );
		if ( ! is_array( $payload ) ) {
			wp_die( 'Payload non valido.', 'Errore', [ 'response' => 400 ] );
		}

		$in = [
			'listino_escl' => self::parse_num( $payload['listino_escl'] ?? 0 ),
			'iva'          => self::parse_num( $payload['iva'] ?? 0 ),
			'sconto'       => self::parse_num( $payload['sconto'] ?? 0 ),
			'ricarico'     => self::parse_num( $payload['ricarico'] ?? 0 ),
			'margine'      => self::parse_num( $payload['margine'] ?? 0 ),
		];

		$out = self::compute( $in );

		$meta = [
			'product_id' => isset( $payload['product_id'] ) ? (int) $payload['product_id'] : 0,
			'sku' => isset( $payload['sku'] ) ? sanitize_text_field( (string) $payload['sku'] ) : '',
			'product_name' => isset( $payload['product_name'] ) ? sanitize_text_field( (string) $payload['product_name'] ) : '',
		];

		// Salva anche nello storico (così "ultimo calcolo" è coerente)
		self::insert_history( get_current_user_id(), $meta, $out );

		self::csv_send_headers( 'ultimo-calcolo-margine.csv' );

		$fh = fopen( 'php://output', 'w' );

		fputcsv( $fh, [ 'campo', 'valore' ] );

		$rows = [
			[ 'prodotto', $meta['product_name'] ?: $meta['sku'] ?: '' ],
			[ 'listino_iva_escl', (string) $out['listino_escl'] ],
			[ 'iva_%', (string) ( $out['iva_rate'] * 100 ) ],
			[ 'sconto_%', (string) ( $out['sconto_rate'] * 100 ) ],
			[ 'listino_iva_incl', (string) $out['listino_incl'] ],
			[ 'prezzo_tuo_iva_incl', (string) $out['prezzo_tuo_incl'] ],
			[ 'costo_reale_senza_iva', (string) $out['costo_reale'] ],

			[ 'ricarico_%', (string) ( $out['ricarico_rate'] * 100 ) ],
			[ 'vendita_senza_iva_da_ricarico', (string) $out['vendita_escl_ric'] ],
			[ 'vendita_iva_incl_da_ricarico', (string) $out['vendita_incl_ric'] ],
			[ 'margine_reale_risultante_%', (string) ( $out['margine_reale_ric'] * 100 ) ],
			[ 'margine_euro_iva_escl_da_ricarico', (string) $out['margine_euro_escl_ric'] ],
			[ 'margine_euro_iva_incl_da_ricarico', (string) $out['margine_euro_incl_ric'] ],

			[ 'margine_desiderato_%', (string) ( $out['margine_des_rate'] * 100 ) ],
			[ 'vendita_senza_iva_da_margine', (string) $out['vendita_escl_mar'] ],
			[ 'vendita_iva_incl_da_margine', (string) $out['vendita_incl_mar'] ],
			[ 'ricarico_risultante_%', (string) ( $out['ricarico_ris'] * 100 ) ],
			[ 'margine_euro_iva_escl_da_margine', (string) $out['margine_euro_escl_mar'] ],
			[ 'margine_euro_iva_incl_da_margine', (string) $out['margine_euro_incl_mar'] ],
		];

		foreach ( $rows as $r ) {
			fputcsv( $fh, $r );
		}

		fclose( $fh );
		exit;
	}
}

register_activation_hook( __FILE__, [ 'WP_BiTi_Product_Margine_Calculator', 'activate' ] );
register_deactivation_hook( __FILE__, [ 'WP_BiTi_Product_Margine_Calculator', 'deactivate' ] );
add_action( 'plugins_loaded', [ 'WP_BiTi_Product_Margine_Calculator', 'init' ] );
