(function($){
  function toNumber(raw){
    if(raw === null || raw === undefined) return 0;
    let s = String(raw).trim();
    if(!s) return 0;
    s = s.replace(/\s+/g,'').replace(/€/g,'');
    // IT format: 1.234,56 -> 1234.56
    s = s.replace(/\./g,'').replace(/,/g,'.');
    const v = parseFloat(s);
    return isFinite(v) ? v : 0;
  }

  function fmtMoney(v){
    if(!isFinite(v)) v = 0;
    return v.toLocaleString('it-IT', {minimumFractionDigits:2, maximumFractionDigits:2});
  }

  function fmtPercent(v){
    if(!isFinite(v)) v = 0;
    return v.toLocaleString('it-IT', {minimumFractionDigits:2, maximumFractionDigits:2}) + '%';
  }

  function clampRate(r){
    if(r < 0) r = 0;
    if(r > 0.999999) r = 0.999999;
    return r;
  }

  function compute(payload){
    const listino_escl = Math.max(0, toNumber(payload.listino_escl));
    const iva_rate = clampRate(toNumber(payload.iva)/100);
    const sconto_rate = clampRate(toNumber(payload.sconto)/100);
    const ric_rate = Math.max(0, toNumber(payload.ricarico)/100);
    const mar_rate = clampRate(toNumber(payload.margine)/100);

    const listino_incl = listino_escl * (1 + iva_rate);
    const prezzo_tuo_incl = listino_incl * (1 - sconto_rate);
    const costo_reale = (1 + iva_rate) > 0 ? (prezzo_tuo_incl / (1 + iva_rate)) : 0;

    // da ricarico
    const vendita_escl_ric = costo_reale * (1 + ric_rate);
    const vendita_incl_ric = vendita_escl_ric * (1 + iva_rate);
    const margine_reale_ric = vendita_escl_ric > 0 ? ((vendita_escl_ric - costo_reale)/vendita_escl_ric) : 0;
    const margine_euro_escl_ric = vendita_escl_ric - costo_reale;
    const margine_euro_incl_ric = vendita_incl_ric - prezzo_tuo_incl;

    // da margine
    const vendita_escl_mar = (1 - mar_rate) > 0 ? (costo_reale / (1 - mar_rate)) : 0;
    const vendita_incl_mar = vendita_escl_mar * (1 + iva_rate);
    const ricarico_ris = costo_reale > 0 ? ((vendita_escl_mar - costo_reale)/costo_reale) : 0;
    const margine_euro_escl_mar = vendita_escl_mar - costo_reale;
    const margine_euro_incl_mar = vendita_incl_mar - prezzo_tuo_incl;

    return {
      listino_escl, iva_rate, sconto_rate, ric_rate, mar_rate,
      listino_incl, prezzo_tuo_incl, costo_reale,
      vendita_escl_ric, vendita_incl_ric, margine_reale_ric, margine_euro_escl_ric, margine_euro_incl_ric,
      vendita_escl_mar, vendita_incl_mar, ricarico_ris, margine_euro_escl_mar, margine_euro_incl_mar,
    };
  }

  function getPayload(){
    return {
      product_id: $('#trcm_product_id').val() || '',
      sku: $('#trcm_sku').val() || '',
      product_name: $('#trcm_product_name').val() || '',
      listino_escl: $('#trcm_listino_escl').val(),
      iva: $('#trcm_iva').val(),
      sconto: $('#trcm_sconto').val(),
      ricarico: $('#trcm_ricarico').val(),
      margine: $('#trcm_margine_des').val(),
    };
  }

  function render(){
    const payload = getPayload();
    const out = compute(payload);

    $('#trcm_out_listino_incl').text(fmtMoney(out.listino_incl));
    $('#trcm_out_prezzo_tuo_incl').text(fmtMoney(out.prezzo_tuo_incl));
    $('#trcm_out_costo_reale').text(fmtMoney(out.costo_reale));

    $('#trcm_out_vendita_escl_ric').text(fmtMoney(out.vendita_escl_ric));
    $('#trcm_out_vendita_incl_ric').text(fmtMoney(out.vendita_incl_ric));
    $('#trcm_out_margine_reale_ric').text(fmtPercent(out.margine_reale_ric*100));
    $('#trcm_out_margine_euro_escl_ric').text(fmtMoney(out.margine_euro_escl_ric));
    $('#trcm_out_margine_euro_incl_ric').text(fmtMoney(out.margine_euro_incl_ric));

    $('#trcm_out_vendita_escl_mar').text(fmtMoney(out.vendita_escl_mar));
    $('#trcm_out_vendita_incl_mar').text(fmtMoney(out.vendita_incl_mar));
    $('#trcm_out_ricarico_ris').text(fmtPercent(out.ricarico_ris*100));
    $('#trcm_out_margine_euro_escl_mar').text(fmtMoney(out.margine_euro_escl_mar));
    $('#trcm_out_margine_euro_incl_mar').text(fmtMoney(out.margine_euro_incl_mar));

    // prepara payload per export ultimo calcolo
    const exportPayload = {
      product_id: payload.product_id,
      sku: payload.sku,
      product_name: payload.product_name,
      listino_escl: payload.listino_escl,
      iva: payload.iva,
      sconto: payload.sconto,
      ricarico: payload.ricarico,
      margine: payload.margine
    };
    $('#trcm_export_last_payload').val(JSON.stringify(exportPayload));
  }

  function setStatus(msg, isOk){
    const $el = $('#trcm_save_status');
    if(!$el.length) return;
    $el.text(msg || '');
    $el.toggleClass('trcm-status--ok', !!isOk);
    $el.toggleClass('trcm-status--err', !isOk);
  }

  function copyText(text){
    if(!text) return;
    if(navigator.clipboard && navigator.clipboard.writeText){
      navigator.clipboard.writeText(text).catch(function(){});
      return;
    }
    const $tmp = $('<textarea>').val(text).appendTo('body').select();
    try { document.execCommand('copy'); } catch(e) {}
    $tmp.remove();
  }

  function bindCopy(){
    $(document).on('click', '.trcm-copy', function(e){
      e.preventDefault();
      const sel = $(this).data('copy');
      const txt = sel ? $(sel).text() : '';
      copyText(txt);
      setStatus('Copiato: ' + txt, true);
      setTimeout(function(){ setStatus('', true); }, 1200);
    });
  }

  function bindInputs(){
    $(document).on('input', '#trcm_listino_escl,#trcm_iva,#trcm_sconto,#trcm_ricarico,#trcm_margine_des', function(){
      render();
    });
  }

  function bindLoadProduct(){
    $(document).on('click', '#trcm_load_product', function(e){
      e.preventDefault();
      const q = ($('#trcm_sku').val() || '').trim();
      if(!q){
        setStatus('Inserisci SKU o ID.', false);
        return;
      }
      setStatus('Caricamento prodotto…', true);
      $.post(TRCM.ajaxUrl, {
        action: 'trcm_get_product',
        nonce: TRCM.nonce,
        query: q
      }).done(function(res){
        if(!res || !res.success){
          setStatus((res && res.data && res.data.message) ? res.data.message : 'Errore.', false);
          return;
        }
        const d = res.data || {};
        $('#trcm_product_id').val(d.product_id || '');
        $('#trcm_product_name').val(d.name || '');
        const info = '✅ ' + (d.name || '') + (d.sku ? (' (SKU: ' + d.sku + ')') : '') +
          ' — Prezzo Woo: ' + fmtMoney(toNumber(d.price_raw)) +
          (d.prices_include_tax ? ' (IVA inclusa in Woo)' : ' (IVA esclusa in Woo)') +
          ' — IVA stimata: ' + fmtPercent(toNumber(d.iva_pct));
        $('#trcm_product_info').text(info);

        // Prefill listino iva esclusa + iva
        if(d.listino_escl !== undefined){
          $('#trcm_listino_escl').val(String(d.listino_escl).replace('.', ','));
        }
        if(d.iva_pct !== undefined){
          $('#trcm_iva').val(String(d.iva_pct).replace('.', ','));
        }

        render();
        setStatus('Prodotto caricato.', true);
        setTimeout(function(){ setStatus('', true); }, 1200);
      }).fail(function(){
        setStatus('Errore richiesta.', false);
      });
    });
  }

  function bindSave(){
    $(document).on('click', '#trcm_save_calc', function(e){
      e.preventDefault();
      const payload = getPayload();
      // quick validation
      if(toNumber(payload.listino_escl) <= 0){
        setStatus('Inserisci un Listino IVA esclusa > 0.', false);
        return;
      }
      setStatus('Salvataggio…', true);
      $.post(TRCM.ajaxUrl, {
        action: 'trcm_save_calc',
        nonce: TRCM.nonce,
        payload: JSON.stringify(payload)
      }).done(function(res){
        if(!res || !res.success){
          setStatus((res && res.data && res.data.message) ? res.data.message : 'Errore salvataggio.', false);
          return;
        }
        if(res.data && res.data.history_html){
          $('#trcm_history_table tbody').html(res.data.history_html);
        }
        setStatus('Salvato nello storico ✅', true);
        setTimeout(function(){ setStatus('', true); }, 1500);
      }).fail(function(){
        setStatus('Errore richiesta.', false);
      });
    });
  }

  function prefillIfEmpty(){
    // Precompila i campi percentuali se vuoti
    const d = (window.TRCM && TRCM.defaults) ? TRCM.defaults : null;
    if(!d) return;

    function setIfEmpty(sel, v){
      const $el = $(sel);
      if(!$el.length) return;
      if(($el.val() || '').trim() === ''){
        $el.val(String(v).replace('.', ','));
      }
    }

    setIfEmpty('#trcm_sconto', d.sconto);
    setIfEmpty('#trcm_iva', d.iva);
    setIfEmpty('#trcm_ricarico', d.ricarico);
    setIfEmpty('#trcm_margine_des', d.margine);
  }

  $(function(){
    bindCopy();
    bindInputs();
    bindLoadProduct();
    bindSave();
    prefillIfEmpty();
    render();
  });
})(jQuery);
